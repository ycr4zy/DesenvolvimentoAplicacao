void main() {
  
  var nomes = ["João", "Roberto"];
  print(nomes.runtimeType);
  
  var id = {1, 2};
  print(id.runtimeType);
  
  var idades = {"João": 15, "Kleber" : 30};
  print(idades.runtimeType);
  
  final nomes2 = ["João", "Roberto"];
  nomes2.add("Teste");
  print(nomes2.runtimeType);
  
  List<dynamic> valores = ["Pedro", 13, true];
  print(valores);
}
